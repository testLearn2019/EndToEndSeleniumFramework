package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import reusables.WebDriverReusables;

public class LoginPage {
	
	WebDriver ldriver;
	
	public LoginPage(WebDriver driver) {
		ldriver=driver;
	}

	public void login() {
		WebDriverReusables reuse = new WebDriverReusables(ldriver);
		
		
		//ldriver.findElement(By.id("txtUsername")).sendKeys("Admin");
		
		reuse.enterText("txtUsername", "Admin");
		reuse.enterText("txtPassword", "admin123");
		
		//ldriver.findElement(By.id("txtPassword")).sendKeys("admin123");
		ldriver.findElement(By.id("btnLogin")).click();
	}
	
}
