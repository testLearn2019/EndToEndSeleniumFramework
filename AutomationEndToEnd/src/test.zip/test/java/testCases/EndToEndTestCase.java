package testCases;

import pages.HomePage;
import pages.LoginPage;
import pages.SystemUsers;

public class EndToEndTestCase extends BaseClass{
	
public static void main(String[] args) {
		browserSetup();
		LoginPage login = new LoginPage(driver);
		login.login();
		HomePage home = new HomePage(driver);
		home.adminMenu();
		SystemUsers users = new SystemUsers(driver);
		users.searchUser();
	}
	

}
