package reusables;

public class GlobalReusables {

}
